## Example — Strict Mode

Recommendation:
- Archdragon (020) @ MID-2

Why:
- Best engine move_strength (0.87).
- Strong mid lane delta (+3).
- Clear tile control from projection_summary.

Alternative:
- Zu (015) @ TOP-3 (0.84), less mid impact.
