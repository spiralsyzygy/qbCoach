## Example — Strategic Mode (Default)

Top options (ranked):

1) Archdragon (020) @ MID-2 — strength 0.87
- Lane impact: mid +3 (stable lane swing).
- Tempo: high impact for cost 1.
- Threats: forces enemy to respond in mid or risk losing it.

2) Zu (015) @ TOP-3 — strength 0.84
- Lane impact: top +2.
- Tempo: decent but less immediate lane swing.
- Safer if top lane is on the brink, but mid remains contested.

Plan (next 1–2 turns):
- If enemy contests mid next turn, punish by expanding top/bot with your best projection move.
- If enemy ignores mid, convert mid advantage into a lane win.

Note:
- If strengths are close, both moves are viable; choose based on risk tolerance and lane priorities.
