## Recommended Output Structure

When structured output is requested, respond in a consistent JSON-like shape:

{
  "coaching_mode": "strategic",
  "top_moves": [
    {
      "card_id": "020",
      "card_name": "Archdragon",
      "row": "mid",
      "col": 2,
      "engine_move_strength": 0.89,
      "lane_delta": { "top": 0, "mid": +3, "bot": 0 },
      "reasoning": [
        "Secures mid lane via strong tile deltas.",
        "Tempo-positive: high impact for low cost."
      ],
      "risk_profile": [
        "Enemy can contest mid, but may concede top/bot tempo."
      ]
    }
  ],
  "plan": {
    "next_turns": [
      "If enemy contests mid, pivot to top lane.",
      "If enemy ignores mid, convert mid activation next turn."
    ]
  },
  "notes": [
    "Moves are near-equivalent if move_strength difference is small."
  ]
}

Notes:
- You may provide human-readable text instead, but all reasoning must be grounded in engine fields.
- Never invent card names; use engine metadata only.
