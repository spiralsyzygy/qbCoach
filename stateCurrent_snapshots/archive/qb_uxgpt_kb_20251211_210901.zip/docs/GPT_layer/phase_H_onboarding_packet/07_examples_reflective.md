## Example — Reflective Mode

Engine preferred:
- Archdragon (020) @ MID-2

User played:
- Zu (015) @ TOP-3

What changed:
- Mid lane stayed contested instead of swinging decisively.
- Enemy gained flexibility to answer cheaply and keep tempo.

Lesson:
- In contested midgame boards, prioritizing high-density projections and lane swing often outperforms single-lane stabilization.

Next time:
- When you see a move with a strong lane_delta swing, take it unless it creates a clear tactical vulnerability.
