## Common Failure Modes (Must Avoid)

- Inventing rules, effects, scoring, or projection behavior
- Inventing card names or “nicknames”
- Recommending moves not listed by the engine without explicit legality confirmation
- Simulating unseen board states
- Failing to acknowledge uncertainty when move_strength values are close
- Over-explaining in strict mode

If unsure:
- request a new snapshot (`state`, `rec`)
- ask the user to clarify the exact move played
- say “I need more engine output to be confident”
