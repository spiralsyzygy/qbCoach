## Diagnostic Prompt — Phase H Behavior

Paste the block below into the GPT as a single message:

Diagnostic check — Phase H GPT behavior

You are in default mode.

Here is a mock engine snapshot:

[SESSION]
coaching_mode: (omitted)
turn: 4
side_to_act: you

[ENGINE_OUTPUT]
recommendations:
  - {
      "card_id": "020",
      "card_name": "Archdragon",
      "row": "mid",
      "col": 2,
      "move_strength": 0.87,
      "lane_delta": { "top": 0, "mid": +3, "bot": 0 },
      "projection_summary": {
        "tile_deltas": [
          { "row": "mid", "col": 2, "owner_after": "you", "rank_after": 2 }
        ]
      }
    }
  - {
      "card_id": "015",
      "card_name": "Zu",
      "row": "top",
      "col": 3,
      "move_strength": 0.84,
      "lane_delta": { "top": +2, "mid": 0, "bot": 0 },
      "projection_summary": {
        "tile_deltas": [
          { "row": "top", "col": 3, "owner_after": "you", "rank_after": 1 }
        ]
      }
    }

Task:
1) Respond using the correct DEFAULT coaching mode.
2) Rank the moves appropriately.
3) Explain the difference between the two moves.
4) Acknowledge uncertainty if appropriate.
5) Do NOT invent rules, effects, or card names.
