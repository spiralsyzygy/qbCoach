# qb_engine/main.py

def main():
    """
    Temporary entry point, just to prove the engine package is wired up.
    We'll replace this with real engine logic later.
    """
    print("qb_engine is alive. 🎴 This is our first Python step in VS Code.")

if __name__ == "__main__":
    main()
