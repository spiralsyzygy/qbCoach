# qb_engine/__init__.py
"""
Queen's Blood Python Engine package.

For now this just marks qb_engine as a Python package.
We'll fill it out step by step.
"""
